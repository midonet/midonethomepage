# How to contibute

There is a .gitreview on the repository so if you have git-review installed,
just do:

    git review
